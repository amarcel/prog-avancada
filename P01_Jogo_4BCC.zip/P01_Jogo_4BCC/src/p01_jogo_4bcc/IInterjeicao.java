
package p01_jogo_4bcc;

public interface IInterjeicao {
    
    public void ataque();
    public void defesa();
    
} // fim da interface
