
package p02_exemplotrycatchfinally;

import java.util.InputMismatchException;
import java.util.Scanner;

public class P02_ExemploTryCatchFinally {

    public static void main(String[] args) {
        int a = 0, b = 0, c;
        Scanner sc = null;
        
        do {
            try {
                sc = new Scanner(System.in);
                System.out.println("Digite valor de a:");
                a = sc.nextInt();
                System.out.println("Digite valor de b:");
                b = sc.nextInt();
                c = a / b;
                System.out.println("Valor do c = " + c);
            } catch (ArithmeticException e1) {
                System.out.println("Erro aritmético: " + e1.getMessage());
            } catch (InputMismatchException e2) {
                System.out.println("Erro entrada inválida: " + e2.getMessage());
            } catch (Exception e3) {
                System.out.println("Erro geral: " + e3.getMessage());
            } finally {
                if (sc != null) {
                    sc.close();
                }
            }
        } while (a >= 0 && b >= 0);
        
    } // fim do main
    
}
