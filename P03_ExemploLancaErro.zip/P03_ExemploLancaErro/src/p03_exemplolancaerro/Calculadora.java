
package p03_exemplolancaerro;

public class Calculadora {
    public double dividir(int n1, int n2) 
        throws Exception {
        if(n2 == 0){
            throw new Exception("Divisão por zero");
        }
        return n1 / n2;
    }
}
