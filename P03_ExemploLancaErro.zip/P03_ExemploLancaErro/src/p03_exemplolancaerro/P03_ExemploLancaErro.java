
package p03_exemplolancaerro;

public class P03_ExemploLancaErro {

    public static void main(String[] args) {
        Calculadora c = new Calculadora();
        try {
            double r = c.dividir(10, 2);
            System.out.println("Resultado: " + r);
        } catch (Exception ex) {
            System.out.println("Erro! " + ex.getMessage());
        }
    }
    
}
